package com.example.retube.adapter;

import android.content.Context;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.retube.R;
import com.example.retube.models.comments.Comment;
import com.example.retube.models.comments.Replies;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

import static android.content.ContentValues.TAG;

public class CommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Comment.Item> commentsList;
    List<List<Replies.Item>> repliesList;
    private SparseBooleanArray mSelectedItems = new SparseBooleanArray(0);

    private RecyclerView.RecycledViewPool viewPool = new RecyclerView.RecycledViewPool();




    public CommentsAdapter(Context context, List<Comment.Item> videoDetailsList, List<List<Replies.Item>> repliesList) {
        this.context = context;
        this.commentsList = videoDetailsList;
        this.repliesList = repliesList;
    }



    class YoutubeHolder extends RecyclerView.ViewHolder{

        ImageView thumbnail;
        TextView title,subtitle;
        Button recomment;
        RecyclerView recommentRecyclerView;


        public YoutubeHolder(@NonNull View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.commentImg);
            title = itemView.findViewById(R.id.userName);
            subtitle = itemView.findViewById(R.id.comment);
            recomment = itemView.findViewById(R.id.recommentBtn);
            recommentRecyclerView = itemView.findViewById(R.id.recommentRecyclerView);

            recomment.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    int realPosition = getAdapterPosition();
                    if (mSelectedItems.get(realPosition, false) == true) {
                        mSelectedItems.delete(realPosition);
                        recommentRecyclerView.setVisibility(View.GONE);
                    } else {
                        mSelectedItems.put(realPosition, true);
                        recommentRecyclerView.setVisibility(View.VISIBLE);
                    }

                }
            });

        }
        public void setData(Comment.Item data){
            String getTitle = data.getSnippet().getTopLevelComment().getSnippet().getAuthorDisplayName();
            String getSubTitle = data.getSnippet().getTopLevelComment().getSnippet().getTextOriginal();
            String getThumb = data.getSnippet().getTopLevelComment().getSnippet().getAuthorProfileImageUrl();
            String getRecommentCount = data.getSnippet().getTotalReplyCount().toString();

            title.setText(getTitle);
            subtitle.setText(getSubTitle);
            if(getRecommentCount.equals("0")){
                recomment.setVisibility(View.GONE);
                //   recommentRecyclerView.setVisibility(View.GONE);
            }else {
                recomment.setVisibility(View.VISIBLE);
                //   recommentRecyclerView.setVisibility(View.VISIBLE);
                recomment.setText("답글 " + getRecommentCount + "개");
            }

            Picasso.get()
                    .load(getThumb)
                    .placeholder(R.mipmap.ic_launcher)
                    .fit()
                    .centerCrop()
                    .into(thumbnail, new Callback() {
                        @Override
                        public void onSuccess() {
                            Log.d(TAG, "Thumbnail success");
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.d(TAG, "Thumbnail error");
                        }
                    });

        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.row_item_comment, parent, false);
        return new YoutubeHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder,int position) {
        Comment.Item videoYT = commentsList.get(position);
        YoutubeHolder yth = (YoutubeHolder) holder;
        yth.setData(videoYT);

        // Create layout manager with initial prefetch item count
        LinearLayoutManager layoutManager = new LinearLayoutManager(
                yth.recommentRecyclerView.getContext(),
                LinearLayoutManager.VERTICAL,
                false
        );
        layoutManager.setInitialPrefetchItemCount(repliesList.get(position).size());

        // Create sub item view adapter
        SubCommentsAdapter subItemAdapter = new SubCommentsAdapter(context,repliesList.get(position));

        yth.recommentRecyclerView.setLayoutManager(layoutManager);
        yth.recommentRecyclerView.setAdapter(subItemAdapter);
        yth.recommentRecyclerView.setRecycledViewPool(viewPool);

        if (mSelectedItems.get(position, false) == true) {
            yth.recommentRecyclerView.setVisibility(View.VISIBLE);
        } else {
            yth.recommentRecyclerView.setVisibility(View.GONE);
        }


    }

    @Override
    public int getItemCount() {

        return commentsList.size();
    }



}
