package com.example.retube.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.retube.DetectPapago;
import com.example.retube.R;
import com.example.retube.Retrofit.GetDataService;
import com.example.retube.Retrofit.RetrofitInstance;
import com.example.retube.adapter.CommentsAdapter;
import com.example.retube.models.VideoStats.VideoStats;
import com.example.retube.models.comments.Comment;
import com.example.retube.models.comments.Replies;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PlayActivity extends YouTubeBaseActivity {

    private YouTubePlayerView youTubePlayerView;
    private YouTubePlayer.OnInitializedListener onInitializedListener;

    private TextView viewCount,likeCount, dislikeCount, commentNum;

    private Button btnCommentAdd;

    private String videoid;

    private RecyclerView commentRecyclerView;
    private CommentsAdapter commentsAdapter;

    private String nextToken;
    private List<Comment.Item> koreanComments = new ArrayList<>();
    List<List<Replies.Item>> repliesList = new ArrayList<>();


    private int lastVisibleItemPosition = 0;
    private boolean firstCommentToken = false;

    private DetectPapago detectPapago = new DetectPapago();

    private int beforeListNum = 0;
    private boolean beforeAdd = false;

    private int papagoCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play);

        Intent intent = getIntent(); /*데이터 수신*/
        videoid = intent.getExtras().getString("videoID"); /*String형*/


        youTubePlayerView = findViewById(R.id.youtubePlay);
        commentRecyclerView = findViewById(R.id.recyclerView);
        viewCount = findViewById(R.id.viewCount);
        likeCount = findViewById(R.id.likeCount);
        dislikeCount = findViewById(R.id.dislikeCount);
        commentNum = findViewById(R.id.commentNum);
        btnCommentAdd = findViewById(R.id.BtnCommentAdd);
        commentsAdapter = new CommentsAdapter(PlayActivity.this,koreanComments,repliesList);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(PlayActivity.this);
        commentRecyclerView.setLayoutManager(layoutManager);
        commentRecyclerView.setAdapter(commentsAdapter);


        btnCommentAdd.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                //댓글 새로 갱신할 때
                System.out.println("갱신시작");
                getCommentData();
            }
        }) ;


        onInitializedListener = new YouTubePlayer.OnInitializedListener() {
            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {

                youTubePlayer.loadVideo(videoid);
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {

            }
        };

        youTubePlayerView.initialize("AIzaSyDDy3bLYFNDyZP7E5C4u8TZ_60F_BpL5J0", onInitializedListener);

        System.out.println("ddd");
        getVideoDetail();
        getCommentData();

    }

    private void getVideoDetail() {

        GetDataService dataService = RetrofitInstance.getRetrofit().create((GetDataService.class));
        Call<VideoStats> videoDetailRequest = dataService
                .getVideoDetail("statistics", "AIzaSyDDy3bLYFNDyZP7E5C4u8TZ_60F_BpL5J0",videoid);
        videoDetailRequest.enqueue(new Callback<VideoStats>() {
            @Override
            public void onResponse(Call<VideoStats> call, Response<VideoStats> response) {

                if(response.isSuccessful()){
                    if(response.body()!=null){

                        viewCount.setText("조회수 " + response.body().getItems().get(0).getStatistics().getViewCount() + "회");
                        likeCount.setText(response.body().getItems().get(0).getStatistics().getLikeCount());
                        dislikeCount.setText(response.body().getItems().get(0).getStatistics().getDislikeCount());
                        commentNum.setText("댓글개수 " + response.body().getItems().get(0).getStatistics().getCommentCount());


                    }else{
                        System.out.println("실패");
                    }
                }else{
                    System.out.println("실패dd");
                }

            }

            @Override
            public void onFailure(Call<VideoStats> call, Throwable t) {

            }
        });
    }


    private void getCommentData() {
        System.out.println("getCommentData() 시작");
        GetDataService dataService = RetrofitInstance.getRetrofit().create((GetDataService.class));
        Call<Comment.Model> commentsRequest = null;

        if(nextToken == null){
            if(firstCommentToken == false) {
                firstCommentToken = true;
                commentsRequest = dataService
                        .getCommentsData("snippet", videoid, "relevance",20, "AIzaSyDDy3bLYFNDyZP7E5C4u8TZ_60F_BpL5J0");
            }else{
                return;
            }
        }else{
            commentsRequest = dataService
                    .getMoreCommentData("snippet",videoid, "relevance",nextToken,20, "AIzaSyDDy3bLYFNDyZP7E5C4u8TZ_60F_BpL5J0");


        }

        commentsRequest.enqueue(new Callback<Comment.Model>() {
            @Override
            public void onResponse(Call<Comment.Model> call, Response<Comment.Model> response) {

                if(response.isSuccessful()){
                    if(response.body()!=null){
                        // commentNum.setText("댓글 개수".concat(String.valueOf(response.body().getItems().size())));

                        if(response.body().getnextPageToken() != null){
                            nextToken = response.body().getnextPageToken();
                        }else{
                            nextToken = null;
                        }


                        if(!beforeAdd){ //추가시도 안했으면
                            beforeListNum = koreanComments.size();
                        }

                        System.out.println(beforeListNum);

                        koreanComments.addAll(detectPapago(response.body().getItems()));
                        commentsAdapter.notifyDataSetChanged();
                        commentRecyclerView.smoothScrollToPosition(lastVisibleItemPosition + 1);
                        System.out.println(koreanComments.size());


                        if(koreanComments.size() - beforeListNum < 10 && nextToken != null){
                            System.out.println("추가시도");
                            beforeAdd = true;
                            getCommentData();

                        }else{
                            System.out.println("추가시도xx");
                            beforeAdd = false;
                        }


                    }else{
                        System.out.println("실패");
                    }
                }else{
                    System.out.println("댓글 불러오기 실패");
                }

            }

            @Override
            public void onFailure(Call<Comment.Model> call, Throwable t) {

            }
        });






    }


    private List<Comment.Item> detectPapago(final List<Comment.Item> item) {
        final List<Comment.Item> list = new ArrayList<>();
        papagoCount += 1;

        int beforeRepliesListCount = 0;
        if(papagoCount == 1){
           // int beforeRepliesListCount = koreanComments.size();
        }else{
            beforeRepliesListCount = koreanComments.size();
        }


        final int realBeforeNum = beforeRepliesListCount;
        System.out.println("papagoCount");
        System.out.println(papagoCount);
        System.out.println(realBeforeNum);

        Thread thread = new Thread()
        {
            public void run() {
                for (int i = 0; i < item.size(); i++) {

                    String before = item.get(i).getSnippet().getTopLevelComment().getSnippet().getTextOriginal();
                    String code = detectPapago.startDetect(before);
                    if(code.equals("ko")){
                        list.add(item.get(i));
                        final int listnum = list.size() -1;
                        List<Replies.Item> discard = new ArrayList<>();
                        repliesList.add(discard);

                        if(item.get(i).getSnippet().getTotalReplyCount() > 0){
                            GetDataService dataService = RetrofitInstance.getRetrofit().create((GetDataService.class));
                            Call<Replies> repliesRequest = null;
                            repliesRequest = dataService
                                    .getRepliesData("snippet", item.get(i).getId(),20, "AIzaSyDDy3bLYFNDyZP7E5C4u8TZ_60F_BpL5J0");

                            repliesRequest.enqueue(new retrofit2.Callback<Replies>() {
                                @Override
                                public void onResponse(Call<Replies> call, Response<Replies> response) {

                                    if(response.isSuccessful()){
                                        if(response.body()!=null){

                                            repliesList.get(listnum+realBeforeNum).addAll(response.body().getItems());
                                            System.out.println("리스트 개수" + repliesList.get(listnum+realBeforeNum).size());

                                        }else{
                                            System.out.println("실패");
                                        }
                                    }else{
                                        System.out.println("실패dd");
                                    }

                                }

                                @Override
                                public void onFailure(Call<Replies> call, Throwable t) {

                                }
                            });
                        }else{

                        }


                    }

                }
            }
        };
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }



        return list;
    }

}
