package com.example.retube.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.retube.R;
import com.example.retube.models.comments.Comment;
import com.example.retube.models.comments.Replies;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

import static android.content.ContentValues.TAG;

public class SubCommentsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Replies.Item> commentsList;

    public SubCommentsAdapter(Context context, List<Replies.Item> videoDetailsList) {
        this.context = context;
        this.commentsList = videoDetailsList;
    }



    class YoutubeHolder extends RecyclerView.ViewHolder{

        ImageView thumbnail;
        TextView title,subtitle;
        Button recomment;
        RecyclerView recommentRecyclerView;


        public YoutubeHolder(@NonNull View itemView) {
            super(itemView);
            thumbnail = itemView.findViewById(R.id.commentImg);
            title = itemView.findViewById(R.id.userName);
            subtitle = itemView.findViewById(R.id.comment);
            recomment = itemView.findViewById(R.id.recommentBtn);


        }
        public void setData(Replies.Item data){
            String getTitle = data.getSnippet().getAuthorDisplayName();
            String getSubTitle = data.getSnippet().getTextOriginal();
            String getThumb = data.getSnippet().getAuthorProfileImageUrl();

            title.setText(getTitle);
            subtitle.setText(getSubTitle);
            recomment.setVisibility(View.GONE);

            Picasso.get()
                    .load(getThumb)
                    .placeholder(R.mipmap.ic_launcher)
                    .fit()
                    .centerCrop()
                    .into(thumbnail, new Callback() {
                        @Override
                        public void onSuccess() {
                            Log.d(TAG, "Thumbnail success");
                        }

                        @Override
                        public void onError(Exception e) {
                            Log.d(TAG, "Thumbnail error");
                        }
                    });

        }
    }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.row_item_comment, parent, false);
        return new YoutubeHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        Replies.Item videoYT = commentsList.get(position);
        YoutubeHolder yth = (YoutubeHolder) holder;
        yth.setData(videoYT);
    }

    @Override
    public int getItemCount() {
        return commentsList.size();
    }


}
